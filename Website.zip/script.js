const apiKey = 'AIzaSyCNRkC62_12AuJbgwg95ASIKk9tnrrIMpc';
const clientId = '907872133745-3o3ij9e2aq9sc5mtb15gcv7e4ta1m209.apps.googleusercontent.com'; // Your Client ID

let gapiLoaded = false;
let auth2;

function loadGapi() {
    gapi.load('auth2', () => {
        auth2 = gapi.auth2.init({
            client_id: clientId,
            scope: 'https://www.googleapis.com/auth/youtube.readonly profile email'
        });
        gapiLoaded = true;
        updateProfile();
    });
}

async function fetchLatestVideos() {
    try {
        const response = await fetch(
            `https://www.googleapis.com/youtube/v3/search?part=snippet&q=video%20edits&order=date&type=video&maxResults=20&key=${apiKey}`
        );
        const data = await response.json();
        if (data.items) {
            renderVideos(data.items);
        } else {
            alert("No latest video edits found.");
        }
    } catch (error) {
        alert("Error fetching latest videos: " + error.message);
    }
}

async function searchVideos() {
    let query = document.getElementById("searchInput").value.trim();
    if (!query) {
        alert("Please enter a search term!");
        return;
    }
    let allVideos = [];
    let nextPageToken = '';

    try {
        do {
            const response = await fetch(
                `https://www.googleapis.com/youtube/v3/search?part=snippet&q=${encodeURIComponent(query)}&type=video&maxResults=50&key=${apiKey}&pageToken=${nextPageToken}`
            );
            const data = await response.json();
            if (data.items) {
                allVideos = allVideos.concat(data.items);
            }
            nextPageToken = data.nextPageToken || '';
        } while (nextPageToken && allVideos.length < 200);

        if (allVideos.length > 0) {
            renderVideos(allVideos);
            document.getElementById("subscribeStatus").textContent = `Loaded ${allVideos.length} videos`;
        } else {
            alert("No videos found for: " + query);
        }
    } catch (error) {
        alert("Error fetching search results: " + error.message);
    }
}

function renderVideos(videos) {
    const container = document.getElementById("video-grid");
    if (!container) {
        alert("Error: Video grid not found in HTML!");
        return;
    }
    container.innerHTML = '<h2>Featured Videos</h2>';
    videos.forEach(video => {
        const videoElement = document.createElement('div');
        videoElement.className = 'video-item';
        videoElement.innerHTML = `
            <iframe 
                src="https://www.youtube.com/embed/${video.id.videoId}" 
                frameborder="0" 
                allowfullscreen 
                loading="lazy">
            </iframe>
            <p>${video.snippet.title}</p>
            <button onclick="subscribeToChannel('${video.snippet.channelId}')">
                ${isSubscribed(video.snippet.channelId) ? 'Unsubscribe' : 'Subscribe'}
            </button>
        `;
        container.appendChild(videoElement);
    });
}

// Google Sign-In Functions
function handleGoogleSignIn() {
    if (!gapiLoaded) {
        alert("Google API not loaded yet, please wait!");
        return;
    }
    auth2.signIn().then(googleUser => {
        const profile = googleUser.getBasicProfile();
        localStorage.setItem("googleUser", JSON.stringify({
            id: profile.getId(),
            name: profile.getName(),
            email: profile.getEmail(),
            token: googleUser.getAuthResponse().access_token
        }));
        updateProfile();
        alert("Signed in as " + profile.getName());
    }).catch(error => {
        alert("Sign-in failed: " + error.message);
    });
}

function handleSignOut() {
    if (auth2) {
        auth2.signOut().then(() => {
            localStorage.removeItem("googleUser");
            updateProfile();
            alert("Signed out!");
        });
    }
}

function updateProfile() {
    const userData = JSON.parse(localStorage.getItem("googleUser") || "{}");
    const profile = document.getElementById("userProfile");
    const signInBtn = document.getElementById("googleSignInBtn");
    const signOutBtn = document.getElementById("signOutBtn");
    if (userData.name) {
        profile.textContent = `Welcome, ${userData.name}!`;
        signInBtn.style.display = "none";
        signOutBtn.style.display = "inline-block";
    } else {
        profile.textContent = "";
        signInBtn.style.display = "inline-block";
        signOutBtn.style.display = "none";
    }
}

async function subscribeToChannel(channelId) {
    const userData = JSON.parse(localStorage.getItem("googleUser") || "{}");
    if (!userData.token) {
        alert("Please sign in with Google to subscribe!");
        return;
    }
    try {
        const response = await fetch(
            `https://www.googleapis.com/youtube/v3/subscriptions?part=snippet&mine=true`,
            {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${userData.token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    snippet: {
                        resourceId: {
                            kind: 'youtube#channel',
                            channelId: channelId
                        }
                    }
                })
            }
        );
        if (response.ok) {
            alert("Subscribed to channel!");
        } else {
            alert("Failed to subscribe, possibly already subscribed.");
        }
    } catch (error) {
        alert("Error subscribing: " + error.message);
    }
    fetchLatestVideos();
}

function isSubscribed(channelId) {
    return false; // Placeholder, requires additional API call
}

window.onload = () => {
    loadGapi();
    fetchLatestVideos();
};